package br.com.alura.screenmatch.modelos;

public record TituloOMDB(String title, String year, String runtime) {
}
